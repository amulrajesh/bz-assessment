package com.ar.bzassesment.exception;

public class RecipeCreationException extends Exception {
    private static final long serialVersionUID = 1L;

    public RecipeCreationException(String message) {
        super(message);
    }
}
