package com.ar.bzassesment.model;

public record LoginRequest(String username, String password) {
}
